function MyFirstFunction() {
	console.log("this is my first function");
}

MyFirstFunction();